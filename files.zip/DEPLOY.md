# BadgeScan — DigitalOcean App Platform Deployment Guide

## Prerequisites

Before you start, make sure you have:

1. A **DigitalOcean account** — sign up at [cloud.digitalocean.com](https://cloud.digitalocean.com/registrations/new)
2. A **GitHub account** with your BadgeScan code pushed to a repo
3. Your **API keys** ready:
   - Anthropic API key ([console.anthropic.com](https://console.anthropic.com/))
   - Apollo API key ([app.apollo.io → Settings → API](https://app.apollo.io/#/settings/integrations/api))
   - Zoho CRM OAuth credentials ([api-console.zoho.com](https://api-console.zoho.com/))

---

## Step 1: Push Code to GitHub

```bash
cd badgescan

# Initialize git repo
git init
git add .
git commit -m "Initial commit — BadgeScan app"

# Create repo on GitHub, then push
git remote add origin https://github.com/YOUR_USERNAME/badgescan.git
git branch -M main
git push -u origin main
```

---

## Step 2: Create the App on DigitalOcean

1. Go to [cloud.digitalocean.com/apps](https://cloud.digitalocean.com/apps)
2. Click **"Create App"**
3. Select **GitHub** as your source
4. Authorize DigitalOcean to access your GitHub account (if not already done)
5. Select your **badgescan** repository and the **main** branch
6. Click **Next**

---

## Step 3: Configure the App

App Platform will auto-detect the Dockerfile. If it doesn't, select **Dockerfile** as the build method.

**Resource settings:**
- **Name:** badgescan
- **Region:** New York (or closest to you)
- **Plan:** Basic → $5/mo (1 vCPU, 512 MB RAM) — this is enough to start
- **HTTP Port:** 8080 (matches our Dockerfile)

Click **Next**.

---

## Step 4: Add Environment Variables

This is the most important step. Go to **Settings → App-Level Environment Variables** and add these (all marked as **Encrypted / Secret**):

| Variable | Value | Type |
|----------|-------|------|
| `ANTHROPIC_API_KEY` | `sk-ant-xxxxx...` | 🔒 Secret |
| `APOLLO_API_KEY` | Your Apollo key | 🔒 Secret |
| `ZOHO_CLIENT_ID` | Your Zoho client ID | 🔒 Secret |
| `ZOHO_CLIENT_SECRET` | Your Zoho client secret | 🔒 Secret |
| `ZOHO_REFRESH_TOKEN` | Your Zoho refresh token | 🔒 Secret |
| `ZOHO_API_DOMAIN` | `https://www.zohoapis.com` | Plain |
| `NODE_ENV` | `production` | Plain |

Click **Save**.

---

## Step 5: Deploy

1. Click **"Create Resources"** or **"Launch App"**
2. Watch the build logs — it takes about 2-3 minutes
3. Once you see ✅ **"Deployed successfully"**, click the **Live App** URL

Your app is now live at something like:
```
https://badgescan-xxxxx.ondigitalocean.app
```

---

## Step 6: Test the Live App

1. Open the app URL on your **phone**
2. Tap **"Open Camera"** or upload a badge photo
3. Claude Vision should extract the contact data
4. Go to **Contacts** tab → **Enrich All** to pull Apollo data
5. Go to **Pipeline** tab → **Push to Zoho** to sync to your CRM

---

## Zoho CRM Setup (if you haven't done this yet)

Getting the Zoho refresh token is the trickiest part. Here's the exact process:

### 1. Register a Self Client
- Go to [api-console.zoho.com](https://api-console.zoho.com/)
- Click **"Add Client"** → Select **"Self Client"**
- Note your **Client ID** and **Client Secret**

### 2. Generate Authorization Code
- In the Self Client panel, enter this scope:
  ```
  ZohoCRM.modules.ALL,ZohoCRM.settings.ALL
  ```
- Set duration to **10 minutes**
- Click **"Create"**
- Copy the **authorization code** (it expires in 10 minutes!)

### 3. Exchange Code for Refresh Token
Run this immediately:
```bash
curl -X POST "https://accounts.zoho.com/oauth/v2/token" \
  -d "code=PASTE_YOUR_CODE_HERE" \
  -d "client_id=YOUR_CLIENT_ID" \
  -d "client_secret=YOUR_CLIENT_SECRET" \
  -d "grant_type=authorization_code"
```

The response contains your `refresh_token` — save it, it doesn't expire.

### 4. (Optional) Create LinkedIn Custom Field
If you want Apollo's LinkedIn URLs stored in Zoho:
- Go to **Zoho CRM → Settings → Modules → Contacts → Fields**
- Add a **Single Line** field called "LinkedIn" with API name `LinkedIn`

---

## Custom Domain (Optional)

1. In your App Platform dashboard, go to **Settings → Domains**
2. Click **"Add Domain"**
3. Enter your domain (e.g., `scan.yourcompany.com`)
4. Add the CNAME record DigitalOcean gives you to your DNS provider
5. SSL is automatically provisioned — no setup needed

---

## Scaling Up

If you're scanning lots of badges at events:

| Need | Action |
|------|--------|
| More capacity | Upgrade to **$10/mo** plan (1 vCPU, 1 GB RAM) |
| Multiple users | Increase **instance count** to 2-3 |
| Persistent data | Add a **DigitalOcean Managed Database** ($15/mo for PostgreSQL) |
| Heavy traffic | Enable **auto-scaling** in App Platform settings |

---

## Monitoring & Logs

- **Live logs:** App Platform dashboard → **Runtime Logs** tab
- **Build logs:** Dashboard → **Deployments** tab → click any deployment
- **Alerts:** Set up alerts in **Settings → Alerts** for downtime or high memory usage

---

## Auto-Deploy on Git Push

This is enabled by default! Every time you push to `main`, App Platform will:
1. Detect the change
2. Build a new Docker image
3. Deploy with **zero downtime** (old container stays live until new one is ready)

---

## Troubleshooting

**Build fails:**
- Check build logs in the Deployments tab
- Make sure `package.json` and `Dockerfile` are in the repo root
- Try "Force Build and Deploy" with "Clear Build Cache" checked

**App crashes on start:**
- Check runtime logs for missing environment variables
- Ensure all 6 API keys are set in the environment variables section

**Zoho push fails:**
- Verify your refresh token hasn't been revoked
- Make sure the scope includes `ZohoCRM.modules.ALL`
- Check if you're using the right API domain (`.com` for US, `.eu` for EU, `.in` for India)

**Claude Vision returns errors:**
- Check your Anthropic API key is valid
- Ensure images aren't larger than 15 MB

---

## Cost Summary

| Component | Monthly Cost |
|-----------|-------------|
| App Platform (Basic) | $5 |
| Anthropic API (~100 scans) | ~$1-2 |
| Apollo (free tier) | $0 |
| Zoho CRM (free for ≤3 users) | $0 |
| **Total** | **~$5-7/mo** |
